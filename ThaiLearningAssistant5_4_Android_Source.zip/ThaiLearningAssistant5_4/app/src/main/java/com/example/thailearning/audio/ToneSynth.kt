package com.example.thailearning.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * 用真实声学信号合成泰语声调的「音高曲线」。
 *
 * 为什么不用 TTS：设备 TTS 的泰语声调依赖语音包，很多机型读不准，
 * 而声调训练需要稳定、可重复的音高走向。这里直接用正弦波按五度调值合成，
 * 让学习者专注分辨「平 / 低 / 降 / 高 / 升」的音高轮廓。
 */
object ToneSynth {

    private const val SR = 44100

    fun playOne(contour: List<Float>, durationMs: Int = 480, baseHz: Double = 175.0) {
        play(listOf(contour), durationMs, 0, baseHz)
    }

    /** 连续播放两段（用于「同异辨别」），中间插入间隔 */
    fun playPair(a: List<Float>, b: List<Float>, durationMs: Int = 430, gapMs: Int = 450, baseHz: Double = 175.0) {
        play(listOf(a, b), durationMs, gapMs, baseHz)
    }

    private fun play(
        contours: List<List<Float>>,
        durationMs: Int,
        gapMs: Int,
        baseHz: Double
    ) {
        if (contours.isEmpty()) return
        Thread {
            var track: AudioTrack? = null
            try {
                val per = (SR * durationMs / 1000).coerceAtLeast(64)
                val gap = (SR * gapMs / 1000).coerceAtLeast(0)
                val totalSamples = per * contours.size + gap * (contours.size - 1)
                val samples = ShortArray(totalSamples)
                var offset = 0

                contours.forEachIndexed { index, contour ->
                    var phase = 0.0
                    for (i in 0 until per) {
                        val t = if (per > 1) i.toDouble() / (per - 1) else 0.0
                        val safe = if (contour.size >= 2) contour else listOf(1f, 1f)
                        val pos = t * (safe.size - 1)
                        val lo = pos.toInt().coerceIn(0, safe.size - 1)
                        val hi = (lo + 1).coerceAtMost(safe.size - 1)
                        val frac = pos - lo
                        val mult = safe[lo] * (1f - frac.toFloat()) + safe[hi] * frac.toFloat()
                        phase += 2.0 * PI * baseHz * mult / SR

                        // 略带谐波，听感更接近人声元音
                        val s = 0.60 * sin(phase) + 0.22 * sin(2 * phase) + 0.10 * sin(3 * phase) - 0.04 * sin(4 * phase)
                        val attack = (t / 0.07).coerceAtMost(1.0)
                        val release = ((1.0 - t) / 0.20).coerceAtMost(1.0)
                        val env = min(attack, release)
                        samples[offset + i] = (s * env * 0.88 * Short.MAX_VALUE).toInt().toShort()
                    }
                    offset += per
                    if (index < contours.size - 1) offset += gap // 留白即静音
                }

                val minBuf = AudioTrack.getMinBufferSize(
                    SR,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(SR)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(maxOf(minBuf, totalSamples * 2))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                track.play()
                track.write(samples, 0, samples.size)
                Thread.sleep(150)
                track.stop()
            } catch (_: Exception) {
                // 音频不可用时静默失败，界面会提示检查设备音量
            } finally {
                try { track?.release() } catch (_: Exception) {}
            }
        }.start()
    }
}
