package com.example.thailearning.data

/** 字母/元音/声调符号 */
data class Letter(
    val char: String,
    val cls: String,          // 中辅音 / 高辅音 / 低辅音 / 元音 / 声调符号
    val name: String,         // ko kai 等
    val sound: String,        // 近似发音
    val note: String = ""
)

/** 词汇 */
data class Vocab(
    val thai: String,
    val zh: String,
    val roman: String,
    val category: String = "基础",
    val toneHint: String = "" // 仅对少量示例词标注
)

/** 五个声调；contour 为相对音高曲线（1.0 = 基准音高） */
data class ToneInfo(
    val key: String,
    val thaiName: String,
    val zhName: String,
    val contour: List<Float>,
    val hint: String,
    val sample: String,
    val sampleRoman: String,
    val tip: String
)

/** 一笔：按归一化坐标 0~100 记录折线点 */
data class Stroke(val points: List<Pair<Float, Float>>)

/** 一个字形的笔顺数据 */
data class Glyph(
    val char: String,
    val strokes: List<Stroke>,
    val caption: String = ""
) {
    val strokeCount: Int get() = strokes.size
}

/** 30 天计划中的一天 */
data class DayPlan(
    val day: Int,
    val title: String,
    val letters: List<String>,
    val words: List<String>,
    val tasks: List<String>,
    val minutes: Int,
    val tip: String
)

/** 错题记忆（SRS 间隔重复） */
data class MistakeRecord(
    val key: String,                 // "v:สวัสดี" / "t:falling" / "l:ก"
    val wrong: Int = 1,
    val correctStreak: Int = 0,
    val dueEpochDay: Long = 0,
    val lastSeenEpochDay: Long = 0,
    val mastered: Boolean = false
)

/** 训练题目（闯关、复习、声调测试共用） */
data class QuizItem(
    val kind: String,          // vocab_zh / vocab_th / tone_name / tone_pair / letter_class
    val prompt: String,
    val sub: String,
    val options: List<String>,
    val answer: Int,
    val refKey: String,
    val spokenThai: String = "",
    val toneKey: String = "",
    val secondToneKey: String = ""
)

/** 每日学习统计 */
data class DayStat(
    val date: String = "",
    val seconds: Long = 0,
    val reviewTotal: Int = 0,
    val reviewCorrect: Int = 0,
    val quizTotal: Int = 0,
    val quizCorrect: Int = 0,
    val toneTotal: Int = 0,
    val toneCorrect: Int = 0,
    val lettersTraced: Int = 0,
    val tasksDone: Int = 0,
    val xp: Int = 0
)

/** 全部本地学习数据 */
data class Progress(
    val learned: Set<String> = emptySet(),
    val favorites: Set<String> = emptySet(),
    val masteredLetters: Set<String> = emptySet(),
    val mistakes: Map<String, MistakeRecord> = emptyMap(),
    val completedDays: Set<Int> = emptySet(),
    val dayChecks: Map<Int, Set<Int>> = emptyMap(),
    val stats: Map<String, DayStat> = emptyMap(),
    val xp: Int = 0,
    val streak: Int = 0,
    val lastActiveDate: String = "",
    val startDate: String = "",
    val userName: String = "学员",
    val totalSeconds: Long = 0
)

data class CertificateInfo(
    val name: String,
    val levelTitle: String,
    val levelIndex: Int,
    val xp: Int,
    val daysCompleted: Int,
    val wordsLearned: Int,
    val date: String,
    val serial: String
)
