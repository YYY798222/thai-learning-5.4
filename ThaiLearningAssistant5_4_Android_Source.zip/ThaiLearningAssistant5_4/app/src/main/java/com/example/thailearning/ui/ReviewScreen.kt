package com.example.thailearning.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.thailearning.data.CourseData
import com.example.thailearning.data.Progress
import com.example.thailearning.data.QuizItem
import com.example.thailearning.engine.ReportEngine
import com.example.thailearning.engine.SrsEngine
import com.example.thailearning.data.Store

@Composable
fun ReviewScreen(
    progress: Progress,
    onResult: (key: String, correct: Boolean) -> Unit,
    onForget: (key: String) -> Unit,
    onSpeak: (String) -> Unit,
    onPlayContour: (List<Float>) -> Unit
) {
    var items by remember { mutableStateOf<List<QuizItem>>(emptyList()) }
    var index by remember { mutableIntStateOf(0) }
    var answered by remember { mutableStateOf(false) }
    var chosen by remember { mutableStateOf<Int?>(null) }
    var score by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(false) }

    val due = SrsEngine.dueCount(progress)
    val current = items.getOrNull(index)

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionCard(title = "错题驱动复习") {
            Text(
                "系统会按「错得越多、逾期越久」排序，自动生成不同题型；答对后间隔按 1→2→4→7→15→30 天延长，连对 5 次视为掌握。",
                style = MaterialTheme.typography.bodySmall,
                color = Ink.copy(alpha = 0.7f)
            )
            StatLine("今天到期", "$due 题")
            StatLine("错题总数", "${progress.mistakes.size} 题")
            StatLine("已掌握", "${progress.mistakes.values.count { it.mastered }} 题")
            Button(
                enabled = progress.mistakes.isNotEmpty(),
                onClick = {
                    items = SrsEngine.generate(progress, 10).ifEmpty { SrsEngine.warmup(progress, 5) }
                    index = 0
                    answered = false
                    chosen = null
                    score = 0
                    running = items.isNotEmpty()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    when {
                        progress.mistakes.isEmpty() -> "暂无错题，先去闯关或听辨"
                        due > 0 -> "开始复习（$due 题到期）"
                        else -> "生成复习题（含待巩固内容）"
                    }
                )
            }
            if (progress.mistakes.isEmpty()) {
                Text("答错任何一题都会自动记录，并生成对应的复习题。", style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = 0.6f))
            }
        }

        if (running && current != null) {
            SectionCard(title = "第 ${index + 1} / ${items.size} 题") {
                LinearProgressIndicator(progress = { index / items.size.toFloat() }, modifier = Modifier.fillMaxWidth())
                Text(current.prompt, style = MaterialTheme.typography.headlineSmall, color = Ink, fontWeight = FontWeight.Medium)
                Text(current.sub, color = Ink.copy(alpha = 0.7f))
                if (current.spokenThai.isNotBlank() && current.kind == "vocab_zh") {
                    OutlinedButton(onClick = {
                        val tone = current.toneKey
                        if (tone.isNotBlank()) {
                            CourseData.fiveTones.firstOrNull { it.key == tone }?.let { onPlayContour(it.contour) }
                        } else onSpeak(current.spokenThai)
                    }) { Text("听目标发音") }
                }
                if (current.toneKey.isNotBlank()) {
                    Button(onClick = {
                        CourseData.fiveTones.firstOrNull { it.key == current.toneKey }?.let { onPlayContour(it.contour) }
                    }, modifier = Modifier.fillMaxWidth()) { Text("播放声调") }
                }

                current.options.forEachIndexed { i, label ->
                    val isAnswer = answered && i == current.answer
                    val isWrongPick = answered && i == chosen && i != current.answer
                    OutlinedButton(
                        onClick = {
                            if (!answered) {
                                answered = true
                                chosen = i
                                val correct = i == current.answer
                                if (correct) score++
                                onResult(current.refKey, correct)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            label,
                            color = when {
                                isAnswer -> Jade
                                isWrongPick -> Color(0xFFC0392B)
                                else -> Ink
                            },
                            fontWeight = if (isAnswer) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }

                if (answered) {
                    Text(
                        if (chosen == current.answer) "正确！" else "正确答案：${current.options[current.answer]}",
                        color = if (chosen == current.answer) Jade else Color(0xFFC0392B)
                    )
                    Button(onClick = {
                        if (index == items.lastIndex) {
                            running = false
                        } else {
                            index++
                            answered = false
                            chosen = null
                        }
                    }) { Text(if (index == items.lastIndex) "完成本组" else "下一题") }
                }
            }
        }

        if (items.isNotEmpty() && !running) {
            SectionCard(title = "本组完成") {
                Text("$score / ${items.size} 题", style = MaterialTheme.typography.headlineSmall, color = Ink)
                Text("错题已按间隔重复重新排期；巩固后再来一组会更轻松。", color = Ink.copy(alpha = 0.7f))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        items = SrsEngine.generate(progress, 10).ifEmpty { SrsEngine.warmup(progress, 5) }
                        index = 0
                        answered = false
                        chosen = null
                        score = 0
                        running = items.isNotEmpty()
                    }) { Text("再来一组") }
                }
            }
        }

        SectionCard(title = "错题本") {
            if (progress.mistakes.isEmpty()) {
                Text("还没有错题。", color = Ink.copy(alpha = 0.65f))
            } else {
                val today = Store.todayEpoch()
                progress.mistakes.values
                    .sortedWith(compareByDescending<com.example.thailearning.data.MistakeRecord> { it.wrong }.thenBy { it.dueEpochDay })
                    .forEach { rec ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(ReportEngine.labelOf(rec.key), color = Ink, fontWeight = FontWeight.Medium)
                                Text(
                                    "答错 ${rec.wrong} 次 · 连对 ${rec.correctStreak} 次 · " +
                                        if (rec.mastered) "已掌握" else if (rec.dueEpochDay <= today) "今天复习" else "${rec.dueEpochDay - today} 天后复习",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (rec.dueEpochDay <= today) Gold else Ink.copy(alpha = 0.6f)
                                )
                            }
                            TextButton(onClick = { onForget(rec.key) }) { Text("移除") }
                        }
                    }
            }
        }
    }
}
