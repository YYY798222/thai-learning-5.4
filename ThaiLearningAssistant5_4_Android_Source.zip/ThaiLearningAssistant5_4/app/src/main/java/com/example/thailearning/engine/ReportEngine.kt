package com.example.thailearning.engine

import com.example.thailearning.data.CertificateInfo
import com.example.thailearning.data.CourseData
import com.example.thailearning.data.DayStat
import com.example.thailearning.data.Levels
import com.example.thailearning.data.Progress
import com.example.thailearning.data.Store
import com.example.thailearning.data.statOf
import java.time.LocalDate
import kotlin.math.abs

data class WeakPoint(val label: String, val wrong: Int, val due: Boolean)

/** 学习报告、连续天数、薄弱点与证书信息 */
object ReportEngine {

    fun accuracy(total: Int, correct: Int): Int = if (total <= 0) 0 else (correct * 100 / total)

    fun weekly(p: Progress): List<Pair<String, DayStat>> {
        val today = LocalDate.now()
        return (6 downTo 0).map { offset ->
            val date = today.minusDays(offset.toLong()).toString()
            val label = when (offset) {
                0 -> "今天"
                1 -> "昨天"
                else -> "${today.minusDays(offset.toLong()).monthValue}/${today.minusDays(offset.toLong()).dayOfMonth}"
            }
            label to p.statOf(date)
        }
    }

    fun weakPoints(p: Progress, limit: Int = 5): List<WeakPoint> {
        val today = Store.todayEpoch()
        return p.mistakes.values
            .sortedWith(compareByDescending<com.example.thailearning.data.MistakeRecord> { it.wrong }.thenBy { it.dueEpochDay })
            .take(limit)
            .map { WeakPoint(labelOf(it.key), it.wrong, it.dueEpochDay <= today) }
    }

    fun labelOf(key: String): String = when {
        key.startsWith("v:") -> {
            val thai = key.removePrefix("v:")
            val v = CourseData.vocab.firstOrNull { it.thai == thai }
            if (v != null) "词汇 ${v.thai} · ${v.zh}" else "词汇 $thai"
        }
        key.startsWith("t:") -> {
            val k = key.removePrefix("t:")
            val t = CourseData.fiveTones.firstOrNull { it.key == k }
            if (t != null) "声调 · ${t.zhName}（${t.thaiName}）" else "声调 $k"
        }
        key.startsWith("l:") -> {
            val ch = key.removePrefix("l:")
            val l = CourseData.consonants.firstOrNull { it.char == ch }
            if (l != null) "字母 $ch · ${l.cls}" else "字母 $ch"
        }
        else -> key
    }

    fun overallAccuracy(p: Progress): Int {
        val total = p.stats.values.sumOf { it.reviewTotal + it.quizTotal + it.toneTotal }
        val correct = p.stats.values.sumOf { it.reviewCorrect + it.quizCorrect + it.toneCorrect }
        return accuracy(total, correct)
    }

    fun todaySummary(p: Progress): List<String> {
        val s = p.statOf()
        val lv = Levels.of(p.xp)
        val lines = mutableListOf<String>()
        lines += "今天学习 ${s.seconds / 60} 分钟，获得 ${s.xp} XP。"
        if (s.reviewTotal + s.quizTotal + s.toneTotal > 0) {
            lines += "共作答 ${s.reviewTotal + s.quizTotal + s.toneTotal} 题，正确率 ${
                accuracy(
                    s.reviewTotal + s.quizTotal + s.toneTotal,
                    s.reviewCorrect + s.quizCorrect + s.toneCorrect
                )
            }%。"
        } else {
            lines += "今天还没有答题，先做 5 道声调听辨热身吧。"
        }
        if (s.lettersTraced > 0) lines += "笔顺描红 ${s.lettersTraced} 个字母。"
        if (s.tasksDone > 0) lines += "完成 ${s.tasksDone} 项计划任务。"
        lines += "当前等级：${lv.title} · ${p.xp} XP。"
        val due = SrsEngine.dueCount(p)
        if (due > 0) lines += "有 $due 个错题今天到期，建议优先复习。"
        return lines
    }

    fun certificateInfo(p: Progress): CertificateInfo {
        val lv = Levels.of(p.xp)
        val date = Store.today()
        val serial = "TH-" + date.replace("-", "") + "-" + abs((p.userName + date + p.xp).hashCode()).toString().padStart(4, '0').takeLast(4)
        return CertificateInfo(
            name = p.userName.ifBlank { "学员" },
            levelTitle = lv.title,
            levelIndex = lv.index,
            xp = p.xp,
            daysCompleted = p.completedDays.size,
            wordsLearned = p.learned.size,
            date = date,
            serial = serial
        )
    }
}
