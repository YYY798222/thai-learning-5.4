package com.example.thailearning.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.thailearning.data.Levels
import com.example.thailearning.data.Progress
import com.example.thailearning.data.statOf
import com.example.thailearning.engine.ReportEngine
import com.example.thailearning.engine.SrsEngine

@Composable
fun ReportScreen(
    progress: Progress,
    onRename: (String) -> Unit
) {
    val ctx = LocalContext.current
    val today = progress.statOf()
    val week = ReportEngine.weekly(progress)
    val lv = Levels.of(progress.xp)
    var name by remember { mutableStateOf(progress.userName) }
    var certBmp by remember { mutableStateOf<Bitmap?>(null) }
    var certUri by remember { mutableStateOf<Uri?>(null) }
    var certMsg by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionCard(title = "今日学习报告 · ${today.date}") {
            ReportEngine.todaySummary(progress).forEach { line ->
                Text("· $line", color = Ink)
            }
            LinearProgressIndicator(progress = { Levels.nextProgress(progress.xp) }, modifier = Modifier.fillMaxWidth())
            Text(
                if (lv.next != null) "距离 ${Levels.all.firstOrNull { it.minXp == lv.next }?.title ?: "下一等级"} 还差 ${lv.next!! - progress.xp} XP"
                else "已达到最高等级",
                style = MaterialTheme.typography.bodySmall,
                color = Ink.copy(alpha = 0.65f)
            )
        }

        SectionCard(title = "本周学习曲线（XP）") {
            MiniBarChart(week.map { it.first to it.second.xp }, Modifier.fillMaxWidth())
            week.reversed().take(3).forEach { (label, s) ->
                StatLine(
                    label,
                    "${s.seconds / 60} 分钟 · ${s.reviewTotal + s.quizTotal + s.toneTotal} 题 · ${s.xp} XP"
                )
            }
        }

        SectionCard(title = "本周指标") {
            val totalQ = week.sumOf { it.second.reviewTotal + it.second.quizTotal + it.second.toneTotal }
            val correctQ = week.sumOf { it.second.reviewCorrect + it.second.quizCorrect + it.second.toneCorrect }
            StatLine("答题量", "$totalQ 题")
            StatLine("正确率", "${ReportEngine.accuracy(totalQ, correctQ)}%")
            StatLine("描红", "${week.sumOf { it.second.lettersTraced }} 次")
            StatLine("计划任务", "${week.sumOf { it.second.tasksDone }} 项")
            StatLine("连续学习", "${progress.streak} 天")
            StatLine("累计时长", "${progress.totalSeconds / 3600} 小时 ${(progress.totalSeconds % 3600) / 60} 分")
        }

        SectionCard(title = "薄弱点与复习优先级") {
            val weak = ReportEngine.weakPoints(progress, 5)
            if (weak.isEmpty()) {
                Text("暂无薄弱点记录，保持练习即可自动累积。", color = Ink.copy(alpha = 0.65f))
            } else {
                weak.forEachIndexed { i, w ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${i + 1}. ${w.label}", Modifier.weight(1f), color = Ink)
                        Text("错 ${w.wrong} 次${if (w.due) " · 待复习" else ""}", color = if (w.due) Gold else Ink.copy(alpha = 0.6f))
                    }
                }
                Text("今天有 ${SrsEngine.dueCount(progress)} 题到期，去「复习」标签生成新题。", style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = 0.65f))
            }
        }

        SectionCard(title = "等级与证书") {
            Text("${lv.title} · ${lv.subtitle}", style = MaterialTheme.typography.titleMedium, color = Ink)
            Text("${progress.xp} XP · 完成计划 ${progress.completedDays.size} 天 · 掌握词汇 ${progress.learned.size} 个", color = Ink.copy(alpha = 0.7f))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("证书姓名") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onRename(name.ifBlank { "学员" }) }) { Text("保存姓名") }
                Button(
                    enabled = progress.xp >= 100,
                    onClick = {
                        val info = ReportEngine.certificateInfo(progress.copy(userName = name.ifBlank { "学员" }))
                        val bmp = CertificateMaker.build(info)
                        val uri = CertificateMaker.save(ctx, bmp, "ThaiCertificate_${info.date}_${System.currentTimeMillis()}.png")
                        certBmp = bmp
                        certUri = uri
                        certMsg = if (uri != null) "证书已保存到相册（Pictures/ThaiLearning）。" else "保存失败，请检查存储权限后重试。"
                    }
                ) { Text(if (progress.xp >= 100) "生成等级证书" else "满 100 XP 可领取") }
            }
            if (certMsg.isNotBlank()) Text(certMsg, color = if (certUri != null) Jade else Color(0xFFC0392B))
            certBmp?.let { bmp ->
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "学习证书预览",
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
                certUri?.let { uri ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { CertificateMaker.share(ctx, uri) }) { Text("分享证书") }
                        Text("已保存 1 张", Modifier.padding(top = 12.dp), color = Ink.copy(alpha = 0.6f))
                    }
                }
            }
            Text(
                "证书内容完全取自本机学习记录（XP、计划天数、词汇量），不代表任何官方语言能力认证。",
                style = MaterialTheme.typography.bodySmall,
                color = Ink.copy(alpha = 0.6f),
                fontWeight = FontWeight.Normal
            )
        }
    }
}
