package com.example.thailearning.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.thailearning.data.CourseData
import com.example.thailearning.data.Glyph
import com.example.thailearning.data.Letter
import com.example.thailearning.data.StrokeData

private fun DrawScope.scaledPoint(p: Pair<Float, Float>): Offset {
    val pad = size.width * 0.13f
    val w = size.width - pad * 2
    val h = size.height - pad * 2
    return Offset(pad + p.first / 100f * w, pad + p.second / 100f * h)
}

private fun DrawScope.drawStroke(
    stroke: com.example.thailearning.data.Stroke,
    fraction: Float,
    color: Color,
    width: Float
) {
    if (stroke.points.size < 2 || fraction <= 0f) return
    val pts = stroke.points.map { scaledPoint(it) }
    var total = 0f
    val segs = (1 until pts.size).map { i ->
        val len = (pts[i] - pts[i - 1]).getDistance()
        total += len
        Triple(pts[i - 1], pts[i], len)
    }
    if (total <= 0f) return
    var remaining = total * fraction.coerceIn(0f, 1f)
    for ((a, b, len) in segs) {
        if (remaining <= 0f) break
        val f = (remaining / len).coerceAtMost(1f)
        val end = Offset(a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f)
        drawLine(color, a, end, strokeWidth = width, cap = StrokeCap.Round)
        remaining -= len
    }
}

/** 笔顺动画画布 */
@Composable
fun StrokeBoard(
    glyph: Glyph,
    playKey: Int,
    modifier: Modifier = Modifier,
    tracePoints: List<Offset> = emptyList(),
    traceMode: Boolean = false
) {
    val anim = remember(glyph.char) { Animatable(0f) }
    LaunchedEffect(glyph.char, playKey) {
        anim.snapTo(0f)
        anim.animateTo(
            glyph.strokes.size.toFloat(),
            animationSpec = tween(
                durationMillis = 420 * glyph.strokes.size.coerceAtLeast(1),
                easing = LinearEasing
            )
        )
    }

    Box(modifier.fillMaxWidth().aspectRatio(1f).background(Paper, RoundedCornerShape(12.dp))) {
        Canvas(Modifier.fillMaxWidth().aspectRatio(1f)) {
            val baseY = size.height * 0.32f
            drawLine(Color(0xFFE9EFEC), Offset(0f, baseY), Offset(size.width, baseY), strokeWidth = 1.5f)
            drawLine(Color(0xFFE9EFEC), Offset(0f, size.height * 0.5f), Offset(size.width, size.height * 0.5f), strokeWidth = 1.5f)
            drawLine(Color(0xFFE9EFEC), Offset(0f, size.height * 0.74f), Offset(size.width, size.height * 0.74f), strokeWidth = 1.5f)
            drawLine(Color(0xFFEFF3F1), Offset(size.width / 2, 0f), Offset(size.width / 2, size.height), strokeWidth = 1f)

            val width = size.width * 0.052f

            if (traceMode) {
                glyph.strokes.forEach { drawStroke(it, 1f, Color(0xFFE4E9E7), width) }
            }

            glyph.strokes.forEachIndexed { index, stroke ->
                val f = (anim.value - index).coerceIn(0f, 1f)
                if (f > 0f) {
                    if (!traceMode) drawStroke(stroke, f, Jade, width)
                    val start = scaledPoint(stroke.points.first())
                    if (f < 1f) {
                        drawCircle(Gold, radius = width * 0.85f, center = start)
                    }
                }
            }

            if (tracePoints.size > 1) {
                tracePoints.zipWithNext().forEach { (a, b) ->
                    drawLine(Gold, a, b, strokeWidth = width * 0.9f, cap = StrokeCap.Round)
                }
                drawCircle(Gold, radius = width * 0.7f, center = tracePoints.last())
            }
        }
    }
}

@Composable
fun LettersScreen(
    mastered: Set<String>,
    onSpeak: (String) -> Unit,
    onTraceDone: (String) -> Unit,
    onToggleMastered: (String) -> Unit
) {
    var category by remember { mutableStateOf("辅音") }
    var selectedKey by remember { mutableStateOf<String?>(null) }
    var playKey by remember { mutableIntStateOf(0) }
    var traceMode by remember { mutableStateOf(false) }
    var traceClearKey by remember { mutableIntStateOf(0) }
    var tracePoints by remember { mutableStateOf<List<Offset>>(emptyList()) }

    val list: List<Letter> = if (category == "辅音") CourseData.consonants else CourseData.vowels
    val selected: Letter? = list.firstOrNull { it.char == selectedKey } ?: list.firstOrNull()

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("辅音", "元音").forEach { c ->
                FilterChip(selected = category == c, onClick = {
                    category = c; selectedKey = null; traceMode = false; tracePoints = emptyList()
                }, label = { Text(c) })
            }
        }

        if (selected != null) {
            val glyph = StrokeData.glyphFor(selected.char)
            SectionCard(title = "笔顺动画 · ${selected.char}") {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        selected.char,
                        style = MaterialTheme.typography.displaySmall,
                        fontWeight = FontWeight.Medium
                    )
                    Column {
                        Text("${selected.cls} · ${selected.sound}", color = Ink)
                        Text(selected.name, color = Ink.copy(alpha = 0.65f))
                        if (selected.note.isNotBlank()) Text(selected.note, color = Ink.copy(alpha = 0.65f))
                    }
                }

                if (glyph == null) {
                    Text("这个符号暂无笔顺数据，可先用听音记忆。", color = Ink.copy(alpha = 0.7f))
                } else {
                    StrokeBoard(
                        glyph = glyph,
                        playKey = playKey,
                        modifier = Modifier.widthIn(max = 360.dp),
                        tracePoints = if (traceMode) tracePoints else emptyList(),
                        traceMode = traceMode
                    )
                    Text(
                        "共 ${glyph.strokes.size} 笔 · 金色圆点是当前起笔位置。${glyph.caption}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Ink.copy(alpha = 0.6f)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { playKey++ }) { Text("重播笔顺") }
                        OutlinedButton(onClick = { onSpeak(selected.char) }) { Text("听发音") }
                        OutlinedButton(onClick = {
                            traceMode = !traceMode
                            tracePoints = emptyList()
                            traceClearKey++
                        }) { Text(if (traceMode) "结束描红" else "描红练习") }
                    }
                    if (traceMode) {
                        Text("用手指沿着灰色字形描一遍，每描完一次点下面的按钮记录。", style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = 0.65f))
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f)
                                .pointerInput(selected.char, traceClearKey) {
                                    detectDragGestures(
                                        onDragStart = { offset -> tracePoints = listOf(offset) },
                                        onDrag = { change, _ ->
                                            tracePoints = tracePoints + change.position
                                            change.consume()
                                        }
                                    )
                                }
                        ) {
                            StrokeBoard(
                                glyph = glyph,
                                playKey = playKey,
                                tracePoints = tracePoints,
                                traceMode = true
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { tracePoints = emptyList() }) { Text("清除笔迹") }
                            Button(onClick = {
                                tracePoints = emptyList()
                                onTraceDone(selected.char)
                            }) { Text("完成 1 次描红") }
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onToggleMastered(selected.char) }) {
                        Text(if (selected.char in mastered) "已掌握 ✓ 点击取消" else "标记为已掌握")
                    }
                }
            }
        }

        SectionCard(title = "字母表 · 点击查看笔顺") {
            Text(
                if (category == "辅音") "44 个传统辅音，按中 / 高 / 低三类排列；ฃ、ฅ 为古字。" else "元音与符号，注意 เ แ โ ใ ไ 写在辅音之前。",
                style = MaterialTheme.typography.bodySmall,
                color = Ink.copy(alpha = 0.65f)
            )
            list.chunked(4).forEach { rowItems ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    rowItems.forEach { letter ->
                        val isSelected = letter.char == selected?.char
                        Box(Modifier.weight(1f)) {
                            TextButton(
                                onClick = {
                                    selectedKey = letter.char
                                    playKey++
                                    traceMode = false
                                    tracePoints = emptyList()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column {
                                    Text(
                                        letter.char,
                                        style = MaterialTheme.typography.headlineSmall,
                                        color = if (isSelected) Jade else Ink,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        letter.cls.take(2),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Ink.copy(alpha = 0.55f)
                                    )
                                }
                            }
                        }
                    }
                    repeat(4 - rowItems.size) { Box(Modifier.weight(1f)) {} }
                }
            }
        }
    }
}
