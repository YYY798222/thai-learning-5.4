package com.example.thailearning.engine

import com.example.thailearning.data.CourseData
import com.example.thailearning.data.DayPlan
import com.example.thailearning.data.Progress
import com.example.thailearning.data.Store
import com.example.thailearning.data.touchToday
import com.example.thailearning.data.withStat
import java.time.LocalDate

/** 30 天零基础计划的推进、打卡与解锁逻辑 */
object PlanEngine {

    const val TOTAL = 30

    fun currentDay(p: Progress): Int {
        val days = Store.daysBetween(p.startDate.ifBlank { Store.today() }, Store.today())
        return (days + 1).toInt().coerceIn(1, TOTAL)
    }

    fun todayPlan(p: Progress): DayPlan = CourseData.plan[currentDay(p) - 1]

    fun isCompleted(p: Progress, day: Int): Boolean = day in p.completedDays

    /** 已解锁：第 1 天、「今天」及以前、或前一天已完成 */
    fun isUnlocked(p: Progress, day: Int): Boolean =
        day == 1 || day <= currentDay(p) || (day - 1) in p.completedDays

    fun checks(p: Progress, day: Int): Set<Int> = p.dayChecks[day] ?: emptySet()

    fun toggleTask(p: Progress, day: Int, index: Int): Progress {
        val cur = checks(p, day)
        val next = if (index in cur) cur - index else cur + index
        return p.copy(dayChecks = p.dayChecks + (day to next))
    }

    fun allTasksDone(p: Progress, day: Int): Boolean {
        val plan = CourseData.plan.getOrNull(day - 1) ?: return false
        return checks(p, day).size >= plan.tasks.size
    }

    fun completeDay(p: Progress, day: Int): Progress {
        if (day !in 1..TOTAL) return p
        if (day in p.completedDays) return p
        val plan = CourseData.plan[day - 1]
        var next = p.copy(completedDays = p.completedDays + day)
        // 完成任务也产生经验
        next = next.withStat { it.copy(tasksDone = it.tasksDone + plan.tasks.size, xp = it.xp + 25) }
        return next.touchToday()
    }

    fun progressPercent(p: Progress): Int = (p.completedDays.size * 100 / TOTAL).coerceIn(0, 100)

    fun nextUnfinished(p: Progress): Int {
        for (d in 1..TOTAL) if (d !in p.completedDays) return d
        return TOTAL
    }

    fun planDayNumber(p: Progress): Int {
        val start = p.startDate.ifBlank { Store.today() }
        return try { (LocalDate.parse(Store.today()).toEpochDay() - LocalDate.parse(start).toEpochDay() + 1).toInt() } catch (_: Exception) { 1 }
    }
}
