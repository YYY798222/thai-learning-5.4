package com.example.thailearning.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.thailearning.data.CourseData
import com.example.thailearning.data.Levels
import com.example.thailearning.data.MistakeRecord
import com.example.thailearning.data.Progress
import com.example.thailearning.data.Store
import com.example.thailearning.data.Vocab
import com.example.thailearning.data.addStudySeconds
import com.example.thailearning.data.recordAnswer
import com.example.thailearning.data.statOf
import com.example.thailearning.data.touchToday
import com.example.thailearning.data.withStat
import com.example.thailearning.engine.PlanEngine
import com.example.thailearning.engine.ReportEngine
import com.example.thailearning.engine.SrsEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val tabs = listOf("首页", "计划", "笔顺", "声调", "复习", "闯关", "词汇", "情景", "跟读", "报告", "AI")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThaiApp(
    speak: (String) -> Unit,
    playContour: (List<Float>) -> Unit,
    playPair: (List<Float>, List<Float>) -> Unit,
    askAI: suspend (String, String, String) -> String,
    startSpeech: ((String) -> Unit) -> Unit,
    loadConfig: () -> Pair<String, String>,
    saveConfig: (String, String) -> Unit
) {
    val ctx = LocalContext.current
    var progress by remember { mutableStateOf(Store.load(ctx)) }
    var tab by remember { mutableStateOf("首页") }

    LaunchedEffect(Unit) {
        progress = Store.load(ctx).touchToday()
        Store.save(ctx, progress)
        while (true) {
            delay(60_000)
            progress = progress.addStudySeconds(60)
            Store.save(ctx, progress)
        }
    }

    fun update(block: (Progress) -> Progress) {
        val next = block(progress).touchToday()
        progress = next
        Store.save(ctx, next)
    }

    fun answer(key: String, correct: Boolean, kind: String) {
        update { p ->
            p.recordAnswer(Store.today(), kind, correct)
                .let { SrsEngine.onAnswer(it, key, correct) }
        }
    }

    val currentDay = PlanEngine.currentDay(progress)
    val todayPlan = CourseData.plan[currentDay - 1]

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Column {
                    Text("泰语学习助手 5.4", fontWeight = FontWeight.Medium)
                    Text("第 $currentDay 天 · 连续 ${progress.streak} 天 · ${progress.xp} XP", style = MaterialTheme.typography.labelSmall, color = Ink.copy(alpha = 0.6f))
                }
            })
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                tabs.forEach { t ->
                    FilterChip(selected = tab == t, onClick = { tab = t }, label = { Text(t) })
                }
            }

            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                when (tab) {
                    "首页" -> HomeScreen(progress, onTab = { tab = it }, todayPlanTitle = todayPlan.title)
                    "计划" -> PlanScreen(
                        progress = progress,
                        onToggleTask = { day, idx -> update { PlanEngine.toggleTask(it, day, idx) } },
                        onCompleteDay = { day -> update { PlanEngine.completeDay(it, day) } },
                        onRestart = { update { it.copy(completedDays = emptySet(), dayChecks = emptyMap(), startDate = Store.today()) } }
                    )
                    "笔顺" -> LettersScreen(
                        mastered = progress.masteredLetters,
                        onSpeak = speak,
                        onTraceDone = { _ ->
                            update { p ->
                                p.withStat { s -> s.copy(lettersTraced = s.lettersTraced + 1, xp = s.xp + 3) }
                            }
                        },
                        onToggleMastered = { ch ->
                            update { p ->
                                p.copy(masteredLetters = if (ch in p.masteredLetters) p.masteredLetters - ch else p.masteredLetters + ch)
                            }
                        }
                    )
                    "声调" -> ToneScreen(
                        onPlayContour = playContour,
                        onPlayPair = playPair,
                        onSpeak = speak,
                        onToneResult = { correct, toneKey ->
                            answer(SrsEngine.toneKey(toneKey), correct, "tone")
                        }
                    )
                    "复习" -> ReviewScreen(
                        progress = progress,
                        onResult = { key, correct -> answer(key, correct, "review") },
                        onForget = { key -> update { p -> p.copy(mistakes = p.mistakes - key) } },
                        onSpeak = speak,
                        onPlayContour = playContour
                    )
                    "闯关" -> QuizScreen(
                        progress = progress,
                        onSpeak = speak,
                        onPlayContour = playContour,
                        onAnswer = { key, correct -> answer(key, correct, "quiz") },
                        onComplete = { correct, total ->
                            if (correct == total && total > 0) {
                                update { p -> p.withStat { s -> s.copy(xp = s.xp + 10) } }
                            }
                        }
                    )
                    "词汇" -> VocabScreen(
                        progress = progress,
                        onSpeak = speak,
                        onToggleLearned = { thai ->
                            update { p -> p.copy(learned = if (thai in p.learned) p.learned - thai else p.learned + thai) }
                        },
                        onToggleFavorite = { thai ->
                            update { p -> p.copy(favorites = if (thai in p.favorites) p.favorites - thai else p.favorites + thai) }
                        },
                        onAddReview = { thai ->
                            val key = SrsEngine.vocabKey(thai)
                            update { p ->
                                val old = p.mistakes[key]
                                p.copy(
                                    mistakes = p.mistakes + (key to (old ?: MistakeRecord(
                                        key = key,
                                        wrong = 1,
                                        dueEpochDay = Store.todayEpoch(),
                                        lastSeenEpochDay = Store.todayEpoch()
                                    )))
                                )
                            }
                        }
                    )
                    "情景" -> SceneScreen(onSpeak = speak)
                    "跟读" -> SpeakingScreen(
                        onSpeak = speak,
                        startSpeech = startSpeech,
                        onSpeechResult = { recognized, matched ->
                            answer(SrsEngine.vocabKey("สวัสดี"), matched, "review")
                        }
                    )
                    "报告" -> ReportScreen(
                        progress = progress,
                        onRename = { name -> update { it.copy(userName = name) } }
                    )
                    else -> AiScreen(askAI = askAI, loadConfig = loadConfig, saveConfig = saveConfig, onInteract = {
                        update { it.touchToday() }
                    })
                }
            }
        }
    }

    // 这份状态在首次进入时已保存过一次，便于以后端到端恢复
    LaunchedEffect(Unit) { Store.save(ctx, progress) }
}

@Composable
private fun HomeScreen(progress: Progress, onTab: (String) -> Unit, todayPlanTitle: String) {
    val today = progress.statOf()
    val levels = Levels.of(progress.xp)
    val due = SrsEngine.dueCount(progress)
    val dayTasks = PlanEngine.checks(progress, PlanEngine.currentDay(progress)).size

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(SoftJade, RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("สวัสดี · 今天学一点", style = MaterialTheme.typography.titleLarge, color = Ink)
            Text("${levels.title} · ${progress.xp} XP · 连续 ${progress.streak} 天", color = Ink.copy(alpha = 0.75f))
            LinearProgressIndicator(progress = { Levels.nextProgress(progress.xp) }, modifier = Modifier.fillMaxWidth())
        }

        SectionCard(title = "今日计划 · $todayPlanTitle") {
            Text("已完成 $dayTasks / 3 项任务", color = Ink)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onTab("计划") }) { Text("继续计划") }
                OutlinedButton(onClick = { onTab("笔顺") }) { Text("练笔顺") }
            }
        }

        SectionCard(title = "今日数据") {
            StatLine("学习时长", "${today.seconds / 60} 分钟")
            StatLine("答题", "${today.reviewTotal + today.quizTotal + today.toneTotal} 题")
            StatLine(
                "正确率",
                ReportEngine.accuracy(
                    today.reviewTotal + today.quizTotal + today.toneTotal,
                    today.reviewCorrect + today.quizCorrect + today.toneCorrect
                ).toString() + "%"
            )
            StatLine("到期复习", "$due 题")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onTab("复习") }) { Text("复习 $due") }
                OutlinedButton(onClick = { onTab("声调") }) { Text("听辨测试") }
                OutlinedButton(onClick = { onTab("报告") }) { Text("看报告") }
            }
        }

        SectionCard(title = "学习路线") {
            Text("字母笔顺 → 元音与拼读 → 五声调听辨 → 高频词 → 情景会话 → 每日报告与证书", color = Ink.copy(alpha = 0.75f))
            Text("离线可用：44 辅音、元音与符号、五声调说明、50 个高频词、30 天计划与错题本均保存在本机。", style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = 0.6f))
        }
    }
}

@Composable
private fun VocabScreen(
    progress: Progress,
    onSpeak: (String) -> Unit,
    onToggleLearned: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onAddReview: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("全部") }
    val categories = listOf("全部") + CourseData.vocab.map { it.category }.distinct()
    val filtered = CourseData.vocab.filter { v ->
        (category == "全部" || v.category == category) &&
            (query.isBlank() || v.zh.contains(query, true) || v.thai.contains(query, true) || v.roman.contains(query, true))
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("搜索中文 / 泰语 / 罗马音") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            categories.forEach { c ->
                FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) })
            }
        }
        Text("已掌握 ${progress.learned.size} / ${CourseData.vocab.size} · 收藏 ${progress.favorites.size}", style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = 0.65f))

        filtered.forEach { w: Vocab ->
            SectionCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(w.thai, style = MaterialTheme.typography.titleLarge, color = Ink)
                        Text("${w.zh} · ${w.roman}", color = Ink.copy(alpha = 0.75f))
                        Text(w.category, style = MaterialTheme.typography.labelSmall, color = Jade)
                    }
                    Column {
                        TextButton(onClick = { onSpeak(w.thai) }) { Text("听") }
                        TextButton(onClick = { onToggleFavorite(w.thai) }) { Text(if (w.thai in progress.favorites) "★" else "☆") }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onToggleLearned(w.thai) }) {
                        Text(if (w.thai in progress.learned) "已掌握 ✓" else "标记掌握")
                    }
                    OutlinedButton(onClick = { onAddReview(w.thai) }) { Text("加入复习") }
                }
            }
        }
        if (filtered.isEmpty()) Text("没有匹配的词汇。", color = Ink.copy(alpha = 0.6f))
    }
}

@Composable
private fun SceneScreen(onSpeak: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("生活情景短句", style = MaterialTheme.typography.titleLarge, color = Ink)
        Text("先听、再跟读；每个场景记住 2-3 句就能应付旅行。", color = Ink.copy(alpha = 0.7f))
        CourseData.scenes.forEach { (scene, thai, zh) ->
            SectionCard {
                Text(scene, style = MaterialTheme.typography.labelLarge, color = Jade)
                Text(thai, style = MaterialTheme.typography.titleLarge, color = Ink)
                Text(zh, color = Ink.copy(alpha = 0.75f))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onSpeak(thai) }) { Text("播放发音") }
                }
            }
        }
    }
}

@Composable
private fun SpeakingScreen(
    onSpeak: (String) -> Unit,
    startSpeech: ((String) -> Unit) -> Unit,
    onSpeechResult: (String, Boolean) -> Unit
) {
    val target = "สวัสดี"
    var recognized by remember { mutableStateOf("") }
    var matched by remember { mutableStateOf<Boolean?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionCard(title = "跟读练习 · $target") {
            Text("目标意思：你好。先听示范，再录音跟读。", color = Ink)
            Text("示范：สวัสดี (sa-wat-dee)", color = Ink.copy(alpha = 0.7f))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onSpeak(target) }) { Text("先听示范") }
                OutlinedButton(onClick = {
                    startSpeech { text ->
                        recognized = text
                        val normalized = text.replace(" ", "").trim()
                        val ok = normalized.contains(target) || (normalized.isNotBlank() && target.contains(normalized))
                        matched = ok
                        onSpeechResult(text, ok)
                    }
                }) { Text("开始泰语识别") }
            }
            if (recognized.isNotBlank()) {
                Text("识别结果：$recognized", color = Ink)
                Text(
                    if (matched == true) "练习反馈：识别内容与目标短句接近 ✓" else "练习反馈：识别结果与目标不同，建议再听一次并慢速跟读。",
                    color = if (matched == true) Jade else Color(0xFFC0392B)
                )
            }
            Text(
                "说明：系统语音识别只能做文字比对，不能判断声调、音素、口型或语气，因此不给出「发音准确率」，只作为开口练习的记录。",
                style = MaterialTheme.typography.bodySmall,
                color = Ink.copy(alpha = 0.6f)
            )
        }
        SectionCard(title = "开口建议") {
            Text("· 每天跟读 3 句，先慢速求准，再逐步接近自然语速。")
            Text("· 五声调先用「声调」页的听辨训练建立音高记忆。")
            Text("· 录音识别失败多半是麦克风权限或设备没有泰语识别服务。")
        }
    }
}

@Composable
private fun AiScreen(
    askAI: suspend (String, String, String) -> String,
    loadConfig: () -> Pair<String, String>,
    saveConfig: (String, String) -> Unit,
    onInteract: () -> Unit
) {
    var endpoint by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("") }
    var answerText by remember { mutableStateOf("填写 API Key 后即可向 DeepSeek 泰语老师提问。") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        val cfg = loadConfig()
        endpoint = cfg.first
        apiKey = cfg.second
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionCard(title = "DeepSeek 泰语老师") {
            OutlinedTextField(endpoint, { endpoint = it }, label = { Text("API Endpoint") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(apiKey, { apiKey = it }, label = { Text("API Key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Button(onClick = {
                runCatching { saveConfig(endpoint.trim(), apiKey.trim()) }
                    .fold({ answerText = "设置已加密保存到本机。" }, { answerText = "保存失败：${it.message}" })
            }) { Text("加密保存设置") }
            OutlinedTextField(question, { question = it }, label = { Text("向 AI 提问（中文即可）") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Button(
                enabled = !busy,
                onClick = {
                    scope.launch {
                        busy = true
                        onInteract()
                        answerText = askAI(endpoint.trim(), apiKey.trim(), question)
                        busy = false
                    }
                }
            ) { Text(if (busy) "正在请求…" else "发送给 DeepSeek") }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Text(answerText, color = Ink)
            Text(
                "安全提示：Key 使用 Android 加密偏好存储；正式商用建议通过自有后端代理，避免客户端密钥被提取。",
                style = MaterialTheme.typography.bodySmall,
                color = Ink.copy(alpha = 0.6f)
            )
        }
        SectionCard(title = "AI 可以怎么帮你") {
            Text("· 解释某个句子的语法结构")
            Text("· 针对你的错题出 3 道相似练习")
            Text("· 把中文句子翻译成泰语并标注声调")
            Text("AI 回答仅作学习参考，声调仍以「声调」页的听辨练习为准。")
        }
    }
}
