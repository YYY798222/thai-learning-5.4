package com.example.thailearning.engine

import com.example.thailearning.data.CourseData
import com.example.thailearning.data.MistakeRecord
import com.example.thailearning.data.Progress
import com.example.thailearning.data.QuizItem
import com.example.thailearning.data.Store
import kotlin.random.Random

/**
 * 间隔重复 + 错题自动出题引擎。
 *
 * 规则：答错 → 立即到期（今天必须再练）；答对 → 连续正确次数决定下次间隔 1/2/4/7/15/30 天。
 * 题型根据错题类型自动生成：词汇（泰→中 / 中→泰）、声调（听音辨调）、字母（辅音类别）。
 */
object SrsEngine {

    const val KIND_VOCAB = "v"
    const val KIND_TONE = "t"
    const val KIND_LETTER = "l"

    fun vocabKey(thai: String) = "$KIND_VOCAB:$thai"
    fun toneKey(key: String) = "$KIND_TONE:$key"
    fun letterKey(ch: String) = "$KIND_LETTER:$ch"

    private fun intervalFor(streak: Int): Long = when (streak) {
        0 -> 0L
        1 -> 1L
        2 -> 2L
        3 -> 4L
        4 -> 7L
        5 -> 15L
        else -> 30L
    }

    /** 记账：一次作答，返回新的 Progress（含错题与当天的学习统计由调用方合并） */
    fun onAnswer(p: Progress, key: String, correct: Boolean): Progress {
        val today = Store.todayEpoch()
        val old = p.mistakes[key]
        val rec: MistakeRecord = if (correct) {
            if (old == null) return p // 没在错题本里，答对不需要记忆
            val streak = old.correctStreak + 1
            old.copy(
                correctStreak = streak,
                dueEpochDay = today + intervalFor(streak),
                lastSeenEpochDay = today,
                mastered = streak >= 5 && old.wrong <= 2
            )
        } else {
            val base = old ?: MistakeRecord(key, wrong = 0)
            base.copy(
                wrong = base.wrong + 1,
                correctStreak = 0,
                dueEpochDay = today,
                lastSeenEpochDay = today,
                mastered = false
            )
        }
        return p.copy(mistakes = p.mistakes + (key to rec))
    }

    fun dueCount(p: Progress): Int {
        val today = Store.todayEpoch()
        return p.mistakes.values.count { it.dueEpochDay <= today }
    }

    /** 按优先级排序：逾期越久 + 错得越多越靠前 */
    fun priorityList(p: Progress): List<MistakeRecord> {
        val today = Store.todayEpoch()
        return p.mistakes.values.sortedWith(
            compareByDescending<MistakeRecord> { it.wrong }
                .thenBy { it.dueEpochDay }
                .thenBy { it.lastSeenEpochDay }
        ).filter { !it.mastered || it.dueEpochDay <= today }
    }

    /** 根据错题自动生成复习题；若错题不足，用到期优先级次之的题补足 */
    fun generate(p: Progress, limit: Int = 10): List<QuizItem> {
        val rnd = Random(System.currentTimeMillis())
        val records = priorityList(p).take(limit)
        if (records.isEmpty()) return emptyList()
        return records.mapNotNull { buildItem(it, rnd) }
    }

    /** 错题本之外的补充练习：从已学词中随机抽题，保持训练不断档 */
    fun warmup(p: Progress, limit: Int = 5): List<QuizItem> {
        val rnd = Random(System.currentTimeMillis() + 77)
        val pool = CourseData.vocab.filter { it.thai in p.learned }.ifEmpty { CourseData.vocab.take(8) }
        return pool.shuffled(rnd).take(limit).mapNotNull { v ->
            buildVocabItem(v.thai, v.zh, v.roman, rnd, thToZh = rnd.nextBoolean())
        }
    }

    private fun buildItem(rec: MistakeRecord, rnd: Random): QuizItem? = when {
        rec.key.startsWith("$KIND_VOCAB:") -> {
            val thai = rec.key.removePrefix("$KIND_VOCAB:")
            val v = CourseData.vocab.firstOrNull { it.thai == thai }
            v?.let { buildVocabItem(it.thai, it.zh, it.roman, rnd, thToZh = rnd.nextBoolean()) }
        }
        rec.key.startsWith("$KIND_TONE:") -> {
            val k = rec.key.removePrefix("$KIND_TONE:")
            val tone = CourseData.fiveTones.firstOrNull { it.key == k }
            tone?.let {
                val options = CourseData.fiveTones.map { t -> t.zhName }
                val answer = CourseData.fiveTones.indexOfFirst { t -> t.key == k }
                QuizItem(
                    kind = "tone_name",
                    prompt = "听音辨调",
                    sub = "点击播放，这个音节的音高走向属于哪一种声调？",
                    options = options,
                    answer = answer.coerceAtLeast(0),
                    refKey = rec.key,
                    toneKey = k
                )
            }
        }
        rec.key.startsWith("$KIND_LETTER:") -> {
            val ch = rec.key.removePrefix("$KIND_LETTER:")
            val letter = CourseData.consonants.firstOrNull { it.char == ch }
            letter?.let {
                val options = listOf("中辅音", "高辅音", "低辅音")
                QuizItem(
                    kind = "letter_class",
                    prompt = "「$ch」是哪一类辅音？",
                    sub = "回忆字母分类——它决定声调计算方式。",
                    options = options,
                    answer = options.indexOf(it.cls).coerceAtLeast(0),
                    refKey = rec.key,
                    spokenThai = ch
                )
            }
        }
        else -> null
    }

    private fun buildVocabItem(thai: String, zh: String, roman: String, rnd: Random, thToZh: Boolean): QuizItem {
        val all = CourseData.vocab
        val pool = all.filter { it.thai != thai && it.zh != zh }.shuffled(rnd).take(3)
        return if (thToZh) {
            val options = (listOf(zh) + pool.map { it.zh }).shuffled(rnd)
            QuizItem(
                kind = "vocab_zh",
                prompt = thai,
                sub = "这个泰语词是什么意思？",
                options = options,
                answer = options.indexOf(zh),
                refKey = vocabKey(thai),
                spokenThai = thai
            )
        } else {
            val options = (listOf(thai) + pool.map { it.thai }).shuffled(rnd)
            QuizItem(
                kind = "vocab_th",
                prompt = zh,
                sub = "中文对应哪个泰语词？",
                options = options,
                answer = options.indexOf(thai),
                refKey = vocabKey(thai)
            )
        }
    }
}
