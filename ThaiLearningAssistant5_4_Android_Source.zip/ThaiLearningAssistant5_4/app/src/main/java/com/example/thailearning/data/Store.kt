package com.example.thailearning.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/** 本地数据读写 + 日期/统计工具 */
object Store {

    private const val PREFS = "thai_progress_54"
    private const val KEY = "progress_json"

    fun today(): String = LocalDate.now().toString()
    fun todayEpoch(): Long = LocalDate.now().toEpochDay()

    fun daysBetween(from: String, to: String): Long = try {
        (LocalDate.parse(to).toEpochDay() - LocalDate.parse(from).toEpochDay())
    } catch (_: Exception) { 0L }

    fun load(ctx: Context): Progress {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
        if (raw.isBlank()) return Progress(startDate = today())
        return try { parse(JSONObject(raw)) } catch (_: Exception) { Progress(startDate = today()) }
    }

    fun save(ctx: Context, p: Progress) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, toJson(p).toString()).apply()
    }

    private fun parse(j: JSONObject): Progress {
        val learned = j.optJSONArray("learned").toStringSet()
        val favorites = j.optJSONArray("favorites").toStringSet()
        val mastered = j.optJSONArray("mastered").toStringSet()

        val mistakes = linkedMapOf<String, MistakeRecord>()
        j.optJSONObject("mistakes")?.let { m ->
            m.keys().forEach { k ->
                val o = m.optJSONObject(k) ?: return@forEach
                mistakes[k] = MistakeRecord(
                    key = k,
                    wrong = o.optInt("wrong", 1),
                    correctStreak = o.optInt("streak", 0),
                    dueEpochDay = o.optLong("due", 0),
                    lastSeenEpochDay = o.optLong("seen", 0),
                    mastered = o.optBoolean("mastered", false)
                )
            }
        }

        val completed = j.optJSONArray("completedDays").toStringSet().mapNotNull { it.toIntOrNull() }.toSet()

        val checks = linkedMapOf<Int, Set<Int>>()
        j.optJSONObject("dayChecks")?.let { c ->
            c.keys().forEach { k ->
                val day = k.toIntOrNull() ?: return@forEach
                checks[day] = c.optJSONArray(k).toStringSet().mapNotNull { it.toIntOrNull() }.toSet()
            }
        }

        val stats = linkedMapOf<String, DayStat>()
        j.optJSONObject("stats")?.let { st ->
            st.keys().forEach { date ->
                val o = st.optJSONObject(date) ?: return@forEach
                stats[date] = DayStat(
                    date = date,
                    seconds = o.optLong("seconds", 0),
                    reviewTotal = o.optInt("reviewTotal", 0),
                    reviewCorrect = o.optInt("reviewCorrect", 0),
                    quizTotal = o.optInt("quizTotal", 0),
                    quizCorrect = o.optInt("quizCorrect", 0),
                    toneTotal = o.optInt("toneTotal", 0),
                    toneCorrect = o.optInt("toneCorrect", 0),
                    lettersTraced = o.optInt("lettersTraced", 0),
                    tasksDone = o.optInt("tasksDone", 0),
                    xp = o.optInt("xp", 0)
                )
            }
        }

        return Progress(
            learned = learned,
            favorites = favorites,
            masteredLetters = mastered,
            mistakes = mistakes,
            completedDays = completed,
            dayChecks = checks,
            stats = stats,
            xp = j.optInt("xp", 0),
            streak = j.optInt("streak", 0),
            lastActiveDate = j.optString("lastActive", ""),
            startDate = j.optString("startDate", "").ifBlank { today() },
            userName = j.optString("name", "学员"),
            totalSeconds = j.optLong("totalSeconds", 0)
        )
    }

    private fun toJson(p: Progress): JSONObject = JSONObject().apply {
        put("learned", JSONArray(p.learned.toList()))
        put("favorites", JSONArray(p.favorites.toList()))
        put("mastered", JSONArray(p.masteredLetters.toList()))
        put("completedDays", JSONArray(p.completedDays.sorted()))
        put("mistakes", JSONObject().apply {
            p.mistakes.forEach { (k, v) ->
                put(k, JSONObject().apply {
                    put("wrong", v.wrong)
                    put("streak", v.correctStreak)
                    put("due", v.dueEpochDay)
                    put("seen", v.lastSeenEpochDay)
                    put("mastered", v.mastered)
                })
            }
        })
        put("dayChecks", JSONObject().apply {
            p.dayChecks.forEach { (day, set) -> put(day.toString(), JSONArray(set.sorted())) }
        })
        put("stats", JSONObject().apply {
            p.stats.forEach { (date, s) ->
                put(date, JSONObject().apply {
                    put("seconds", s.seconds)
                    put("reviewTotal", s.reviewTotal)
                    put("reviewCorrect", s.reviewCorrect)
                    put("quizTotal", s.quizTotal)
                    put("quizCorrect", s.quizCorrect)
                    put("toneTotal", s.toneTotal)
                    put("toneCorrect", s.toneCorrect)
                    put("lettersTraced", s.lettersTraced)
                    put("tasksDone", s.tasksDone)
                    put("xp", s.xp)
                })
            }
        })
        put("xp", p.xp)
        put("streak", p.streak)
        put("lastActive", p.lastActiveDate)
        put("startDate", p.startDate)
        put("name", p.userName)
        put("totalSeconds", p.totalSeconds)
        put("version", "5.4")
    }
}

private fun JSONArray?.toStringSet(): Set<String> {
    val arr = this ?: return emptySet()
    return (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { v -> v.isNotBlank() } }.toSet()
}

/* ------------------------- 统计与等级 ------------------------- */

fun Progress.statOf(date: String = Store.today()): DayStat = stats[date] ?: DayStat(date)

/** 更新某天统计，并同步总 XP */
fun Progress.withStat(date: String = Store.today(), block: (DayStat) -> DayStat): Progress {
    val current = statOf(date)
    val next = block(current).copy(date = date)
    val xpGain = next.xp - current.xp
    return copy(stats = stats + (date to next), xp = (xp + xpGain).coerceAtLeast(0))
}

/** 记录一次三选一/听力答题 */
fun Progress.recordAnswer(date: String, kind: String, correct: Boolean, xpPerCorrect: Int = 5): Progress =
    withStat(date) { s ->
        when (kind) {
            "review" -> s.copy(
                reviewTotal = s.reviewTotal + 1,
                reviewCorrect = s.reviewCorrect + if (correct) 1 else 0,
                xp = s.xp + if (correct) xpPerCorrect else 0
            )
            "tone" -> s.copy(
                toneTotal = s.toneTotal + 1,
                toneCorrect = s.toneCorrect + if (correct) 1 else 0,
                xp = s.xp + if (correct) (xpPerCorrect + 2) else 0
            )
            else -> s.copy(
                quizTotal = s.quizTotal + 1,
                quizCorrect = s.quizCorrect + if (correct) 1 else 0,
                xp = s.xp + if (correct) xpPerCorrect else 0
            )
        }
    }

/** 标记今日活跃，维护连续学习天数 */
fun Progress.touchToday(): Progress {
    val t = Store.today()
    if (lastActiveDate == t) return this
    val yesterday = LocalDate.now().minusDays(1).toString()
    val newStreak = when {
        lastActiveDate == yesterday -> streak + 1
        lastActiveDate.isBlank() -> 1
        lastActiveDate == t -> streak
        else -> 1
    }
    return copy(lastActiveDate = t, streak = newStreak)
}

fun Progress.addStudySeconds(sec: Long): Progress =
    withStat { it.copy(seconds = it.seconds + sec) }.copy(totalSeconds = totalSeconds + sec)

data class LevelInfo(val index: Int, val title: String, val subtitle: String, val minXp: Int, val next: Int?)

object Levels {
    val all = listOf(
        LevelInfo(1, "入门学员", "字母与元音启蒙", 0, 200),
        LevelInfo(2, "初级学员", "掌握拼读与问候", 200, 500),
        LevelInfo(3, "中级学员", "五声调与生活场景", 500, 1000),
        LevelInfo(4, "高级学员", "综合听说与自主学习", 1000, null)
    )

    fun of(xp: Int): LevelInfo = all.lastOrNull { xp >= it.minXp } ?: all.first()
    fun nextProgress(xp: Int): Float {
        val lv = of(xp)
        val next = lv.next ?: return 1f
        return ((xp - lv.minXp).toFloat() / (next - lv.minXp).toFloat()).coerceIn(0f, 1f)
    }
}
