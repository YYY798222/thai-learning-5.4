package com.example.thailearning.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.thailearning.data.CourseData
import com.example.thailearning.data.ToneInfo
import kotlin.random.Random

data class ToneQuestion(val first: ToneInfo, val second: ToneInfo?)

@Composable
fun ToneScreen(
    onPlayContour: (List<Float>) -> Unit,
    onPlayPair: (List<Float>, List<Float>) -> Unit,
    onSpeak: (String) -> Unit,
    onToneResult: (correct: Boolean, toneKey: String) -> Unit
) {
    val modes = listOf("调类判断", "同异辨别", "音节听辨")
    var mode by remember { mutableStateOf(modes.first()) }
    var questions by remember { mutableStateOf(generateQuestions(modes.first())) }
    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var answered by remember { mutableStateOf(false) }
    var chosen by remember { mutableStateOf<Int?>(null) }
    var finished by remember { mutableStateOf(false) }

    val current: ToneQuestion? = questions.getOrNull(index)
    val options: List<String> = when (mode) {
        "同异辨别" -> listOf("两段相同", "两段不同")
        else -> CourseData.fiveTones.map { it.zhName }
    }
    val answerIndex: Int = if (current == null) 0 else when (mode) {
        "同异辨别" -> if (current.first.key == current.second?.key) 0 else 1
        else -> CourseData.fiveTones.indexOfFirst { it.key == current.first.key }.coerceAtLeast(0)
    }

    fun play(q: ToneQuestion) {
        when (mode) {
            "同异辨别" -> q.second?.let { onPlayPair(q.first.contour, it.contour) }
            "音节听辨" -> onSpeak(q.first.sample)
            else -> onPlayContour(q.first.contour)
        }
    }

    fun submit(idx: Int) {
        if (answered || current == null) return
        answered = true
        chosen = idx
        val correct = idx == answerIndex
        if (correct) score++
        onToneResult(correct, current.first.key)
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionCard(title = "五声调听辨测试") {
            Text(
                "用合成音高曲线训练耳朵，不依赖设备 TTS 的泰语包。每题 10 分，共 10 题；错题会自动进入复习题库。",
                style = MaterialTheme.typography.bodySmall,
                color = Ink.copy(alpha = 0.7f)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                modes.forEach { m ->
                    FilterChip(selected = mode == m, onClick = {
                        mode = m
                        questions = generateQuestions(m)
                        index = 0
                        score = 0
                        answered = false
                        chosen = null
                        finished = false
                    }, label = { Text(m) })
                }
            }
        }

        if (!finished && current != null) {
            SectionCard(title = "第 ${index + 1} / ${questions.size} 题") {
                LinearProgressIndicator(progress = { index / questions.size.toFloat() }, modifier = Modifier.fillMaxWidth())
                Text(
                    when (mode) {
                        "同异辨别" -> "听两段音，判断它们的调型是否相同。"
                        "音节听辨" -> "听泰语音节（设备 TTS），判断它属于哪个声调。"
                        else -> "听一段音高曲线，判断它属于哪个声调。"
                    },
                    color = Ink.copy(alpha = 0.75f)
                )
                if (mode == "音节听辨") {
                    Text("示例音节：${current.first.sample}（${current.first.sampleRoman}）", color = Ink.copy(alpha = 0.6f))
                }
                Button(onClick = { play(current) }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (mode == "同异辨别") "播放两段" else "播放这一段")
                }
                options.forEachIndexed { i, label ->
                    val isAnswer = answered && i == answerIndex
                    val isWrongPick = answered && i == chosen && i != answerIndex
                    OutlinedButton(
                        onClick = { submit(i) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            label,
                            color = when {
                                isAnswer -> Jade
                                isWrongPick -> Color(0xFFC0392B)
                                else -> Ink
                            },
                            fontWeight = if (isAnswer) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
                if (answered) {
                    val samePair = current.first.key == current.second?.key
                    val feedbackText = if (mode == "同异辨别") {
                        if (chosen == answerIndex) {
                            if (samePair) "正确！两段都是${current.first.zhName}。" else "正确！第一段${current.first.zhName}，第二段${current.second?.zhName}。"
                        } else {
                            if (samePair) "正确答案：两段相同，都是${current.first.zhName}。" else "正确答案：两段不同（${current.first.zhName} / ${current.second?.zhName}）。"
                        }
                    } else if (chosen == answerIndex) {
                        "正确！${current.first.zhName}：${current.first.hint}"
                    } else {
                        "正确答案是 ${options[answerIndex]}。${current.first.zhName}：${current.first.hint}"
                    }
                    Text(
                        feedbackText,
                        color = if (chosen == answerIndex) Jade else Color(0xFFC0392B)
                    )
                    Button(onClick = {
                        if (index == questions.lastIndex) finished = true
                        else {
                            index++
                            answered = false
                            chosen = null
                        }
                    }) { Text(if (index == questions.lastIndex) "查看成绩" else "下一题") }
                }
            }
        }

        if (finished) {
            SectionCard(title = "本轮成绩") {
                Text("$score / ${questions.size} 题", style = MaterialTheme.typography.headlineSmall, color = Ink)
                Text(
                    when {
                        score >= 9 -> "音高分辨已经很稳，可以挑战「音节听辨」模式。"
                        score >= 7 -> "基本能分辨，重点再练降调与升调的区别。"
                        else -> "建议先在下方参考卡里逐个听，建立音高记忆。"
                    },
                    color = Ink.copy(alpha = 0.75f)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        questions = generateQuestions(mode)
                        index = 0
                        score = 0
                        answered = false
                        chosen = null
                        finished = false
                    }) { Text("再来一轮") }
                }
            }
        }

        SectionCard(title = "五声调参考") {
            CourseData.fiveTones.forEach { tone ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("${tone.zhName} · ${tone.thaiName}", color = Ink, fontWeight = FontWeight.Medium)
                        Text("${tone.hint}｜示例 ${tone.sample}", style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = 0.7f))
                        Text(tone.tip, style = MaterialTheme.typography.labelSmall, color = Ink.copy(alpha = 0.55f))
                    }
                    OutlinedButton(onClick = { onPlayContour(tone.contour) }) { Text("听") }
                }
            }
            Text(
                "注意：真实泰语声调由「辅音类别 + 元音长短 + 韵尾 + 声调符号」共同决定，这里练的是五个调的音高走向。示例音节中 ม๊า 为示范音节，不是高频词。",
                style = MaterialTheme.typography.bodySmall,
                color = Ink.copy(alpha = 0.6f)
            )
        }
    }
}

private fun generateQuestions(mode: String): List<ToneQuestion> {
    val rnd = Random(System.currentTimeMillis())
    return (1..10).map {
        when (mode) {
            "同异辨别" -> {
                val a = CourseData.fiveTones.random(rnd)
                val same = rnd.nextBoolean()
                val others = CourseData.fiveTones.filter { it.key != a.key }
                val b = if (same) a else others.random(rnd)
                ToneQuestion(a, b)
            }
            else -> ToneQuestion(CourseData.fiveTones.random(rnd), null)
        }
    }
}
