package com.example.thailearning.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Ink = Color(0xFF2C3A43)
val Jade = Color(0xFF2F7D6B)
val Gold = Color(0xFFC9A227)
val Paper = Color(0xFFFDFBF4)
val SoftJade = Color(0xFFE6F2EE)
val SoftGold = Color(0xFFFBF0D2)

@Composable
fun SectionCard(
    title: String? = null,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Column(
            Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (title != null) Text(title, style = MaterialTheme.typography.titleMedium, color = Ink)
            content()
        }
    }
}

@Composable
fun StatLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = Ink.copy(alpha = 0.7f))
        Text(value, style = MaterialTheme.typography.bodyMedium, color = Ink)
    }
}

/** 7 天柱状图（纯 Compose Canvas，无第三方图表依赖） */
@Composable
fun MiniBarChart(values: List<Pair<String, Int>>, modifier: Modifier = Modifier) {
    val maxValue = (values.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
    Column(modifier) {
        Canvas(Modifier.fillMaxWidth().height(120.dp)) {
            val gap = size.width / (values.size.coerceAtLeast(1) * 2f)
            val barWidth = gap * 0.9f
            values.forEachIndexed { i, (_, v) ->
                val left = gap + i * (barWidth + gap)
                val h = (v.toFloat() / maxValue) * (size.height * 0.82f)
                drawLine(
                    color = Color(0xFFE3E8E6),
                    start = Offset(0f, size.height - 1f),
                    end = Offset(size.width, size.height - 1f),
                    strokeWidth = 2f
                )
                drawRect(
                    color = if (v > 0) Jade else Color(0xFFDCE5E2),
                    topLeft = Offset(left, size.height - h - 2f),
                    size = androidx.compose.ui.geometry.Size(barWidth, h.coerceAtLeast(3f))
                )
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            values.forEach { (label, _) ->
                Text(label, style = MaterialTheme.typography.labelSmall, color = Ink.copy(alpha = 0.6f))
            }
        }
    }
}
