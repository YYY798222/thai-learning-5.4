package com.example.thailearning.ui

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.thailearning.data.CertificateInfo
import com.example.thailearning.data.Levels
import java.io.File
import java.io.FileOutputStream

/** 用 Android Canvas 绘制等级证书并保存到相册 / 分享 */
object CertificateMaker {

    private const val W = 1654
    private const val H = 1169

    fun build(info: CertificateInfo): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.parseColor("#FDFBF3"))

        val gold = Color.parseColor("#B08A28")
        val ink = Color.parseColor("#2C3A43")
        val soft = Color.parseColor("#6F7C82")

        // 双线边框
        val outer = Paint().apply { color = gold; style = Paint.Style.STROKE; strokeWidth = 7f; isAntiAlias = true }
        val inner = Paint().apply { color = Color.parseColor("#D8C27C"); style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true }
        c.drawRect(RectF(42f, 42f, W - 42f, H - 42f), outer)
        c.drawRect(RectF(64f, 64f, W - 64f, H - 64f), inner)

        // 顶部泰文
        drawCenter(c, "ใบประกาศนียบัตร", 90f, 34f, soft, bold = false)
        drawCenter(c, "CERTIFICATE OF THAI LANGUAGE LEARNING", 132f, 22f, soft, bold = false)

        // 主标题
        drawCenter(c, "泰语学习等级证书", 230f, 68f, ink, bold = true)
        // 分隔线
        c.drawLine(W / 2f - 200f, 262f, W / 2f + 200f, 262f, Paint().apply {
            color = gold; strokeWidth = 2f; isAntiAlias = true
        })

        drawCenter(c, "兹证明", 340f, 28f, soft, bold = false)
        drawCenter(c, info.name.ifBlank { "学员" }, 420f, 76f, ink, bold = true)
        drawCenter(c, "已完成泰语训练课程，达到", 500f, 28f, soft, bold = false)
        drawCenter(c, info.levelTitle, 590f, 58f, gold, bold = true)

        // 数据行
        drawCenter(c, "累计经验 ${info.xp} XP  ·  完成计划 ${info.daysCompleted} / 30 天  ·  掌握词汇 ${info.wordsLearned} 个", 690f, 26f, soft, bold = false)
        drawCenter(c, "发音、笔顺、声调听辨与情景对话均基于本机真实学习记录生成", 736f, 22f, soft, bold = false)

        // 徽章
        val sealX = W / 2f
        val sealY = 880f
        val sealPaint = Paint().apply {
            color = gold; style = Paint.Style.STROKE; strokeWidth = 5f; isAntiAlias = true
        }
        c.drawCircle(sealX, sealY, 84f, sealPaint)
        c.drawCircle(sealX, sealY, 70f, Paint().apply {
            color = Color.parseColor("#D8C27C"); style = Paint.Style.STROKE; strokeWidth = 2f; isAntiAlias = true
        })
        val star = Paint().apply { color = gold; style = Paint.Style.FILL; isAntiAlias = true }
        val cx = sealX
        val cy = sealY - 18f
        val path = android.graphics.Path()
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) 26f else 10f
            val angle = Math.toRadians((i * 36 - 90).toDouble())
            val x = cx + (r * Math.cos(angle)).toFloat()
            val y = cy + (r * Math.sin(angle)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        c.drawPath(path, star)
        drawCenterAt(c, "CERTIFIED", sealX, sealY + 40f, 18f, gold, bold = true)

        // 底部日期 / 编号
        val small = Paint().apply {
            color = soft; textSize = 26f; isAntiAlias = true; typeface = Typeface.SANS_SERIF
        }
        c.drawText("日期  ${info.date}", 130f, H - 150f, small)
        c.drawText("编号  ${info.serial}", 130f, H - 110f, small)

        val sign = Paint().apply {
            color = ink; textSize = 28f; isAntiAlias = true; typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        }
        c.drawText("Thai Learning Assistant 5.4", W - 470f, H - 130f, sign)
        c.drawLine(W - 470f, H - 118f, W - 130f, H - 118f, Paint().apply {
            color = gold; strokeWidth = 2f; isAntiAlias = true
        })
        c.drawText("学习系统自动签发", W - 470f, H - 82f, Paint().apply {
            color = soft; textSize = 22f; isAntiAlias = true
        })

        // 四角装饰
        val dot = Paint().apply { color = Color.parseColor("#D8C27C"); style = Paint.Style.FILL; isAntiAlias = true }
        listOf(110f to 110f, W - 110f to 110f, 110f to H - 110f, W - 110f to H - 110f).forEach { (x, y) ->
            c.drawCircle(x, y, 8f, dot)
        }

        return bmp
    }

    private fun drawCenter(c: Canvas, text: String, y: Float, size: Float, color: Int, bold: Boolean) {
        val p = Paint().apply {
            this.color = color
            textSize = size
            isAntiAlias = true
            typeface = Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        c.drawText(text, (W - p.measureText(text)) / 2f, y, p)
    }

    private fun drawCenterAt(c: Canvas, text: String, cx: Float, y: Float, size: Float, color: Int, bold: Boolean) {
        val p = Paint().apply {
            this.color = color
            textSize = size
            isAntiAlias = true
            typeface = Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        c.drawText(text, cx - p.measureText(text) / 2f, y, p)
    }

    /** 保存到相册（Android 10+）或应用图片目录（旧系统） */
    fun save(ctx: Context, bitmap: Bitmap, fileName: String): Uri? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ThaiLearning")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return null
                ctx.contentResolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                ctx.contentResolver.update(uri, values, null, null)
                uri
            } else {
                val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: ctx.filesDir
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, fileName)
                FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out) }
                FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
            }
        } catch (_: Exception) {
            null
        }
    }

    fun share(ctx: Context, uri: Uri) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "分享学习证书"))
    }
}
