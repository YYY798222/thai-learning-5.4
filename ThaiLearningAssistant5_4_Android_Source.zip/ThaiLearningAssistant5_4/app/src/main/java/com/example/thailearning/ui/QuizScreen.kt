package com.example.thailearning.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.thailearning.data.CourseData
import com.example.thailearning.data.Progress
import com.example.thailearning.data.QuizItem
import com.example.thailearning.engine.SrsEngine
import kotlin.random.Random

@Composable
fun QuizScreen(
    progress: Progress,
    onSpeak: (String) -> Unit,
    onPlayContour: (List<Float>) -> Unit,
    onAnswer: (key: String, correct: Boolean) -> Unit,
    onComplete: (correct: Int, total: Int) -> Unit
) {
    var level by remember { mutableStateOf("初级") }
    var items by remember { mutableStateOf(buildQuiz("初级")) }
    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var answered by remember { mutableStateOf(false) }
    var chosen by remember { mutableStateOf<Int?>(null) }
    var finished by remember { mutableStateOf(false) }
    val current = items.getOrNull(index)

    fun restart(target: String) {
        items = buildQuiz(target)
        index = 0
        score = 0
        answered = false
        chosen = null
        finished = false
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionCard(title = "每日闯关") {
            Text("答题正确 +5 XP；答错会自动进入错题本，并生成对应的复习题。", style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = 0.7f))
            Text("累计作答 ${progress.stats.values.sumOf { it.quizTotal }} 题 · 正确率 ${progress.stats.values.sumOf { it.quizCorrect } * 100 / progress.stats.values.sumOf { it.quizTotal }.coerceAtLeast(1)}%", style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = 0.65f))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("初级", "进阶", "听力").forEach { l ->
                    FilterChip(selected = level == l, onClick = { level = l; restart(l) }, label = { Text(l) })
                }
            }
        }

        if (!finished && current != null) {
            SectionCard(title = "第 ${index + 1} / ${items.size} 题") {
                LinearProgressIndicator(progress = { index / items.size.toFloat() }, modifier = Modifier.fillMaxWidth())
                Text(current.prompt, style = MaterialTheme.typography.headlineSmall, color = Ink, fontWeight = FontWeight.Medium)
                Text(current.sub, color = Ink.copy(alpha = 0.7f))
                if (current.toneKey.isNotBlank()) {
                    Button(onClick = {
                        CourseData.fiveTones.firstOrNull { it.key == current.toneKey }?.let { onPlayContour(it.contour) }
                    }, modifier = Modifier.fillMaxWidth()) { Text("播放声调") }
                } else if (current.spokenThai.isNotBlank()) {
                    OutlinedButton(onClick = { onSpeak(current.spokenThai) }) { Text("听发音") }
                }
                current.options.forEachIndexed { i, label ->
                    val isAnswer = answered && i == current.answer
                    val isWrongPick = answered && i == chosen && i != current.answer
                    OutlinedButton(
                        onClick = {
                            if (!answered) {
                                answered = true
                                chosen = i
                                val correct = i == current.answer
                                if (correct) score++
                                onAnswer(current.refKey, correct)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            label,
                            color = when {
                                isAnswer -> Jade
                                isWrongPick -> Color(0xFFC0392B)
                                else -> Ink
                            },
                            fontWeight = if (isAnswer) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
                if (answered) {
                    Text(
                        if (chosen == current.answer) "正确！" else "正确答案：${current.options[current.answer]}",
                        color = if (chosen == current.answer) Jade else Color(0xFFC0392B)
                    )
                    Button(onClick = {
                        if (index == items.lastIndex) {
                            finished = true
                            onComplete(score, items.size)
                        } else {
                            index++
                            answered = false
                            chosen = null
                        }
                    }) { Text(if (index == items.lastIndex) "查看成绩" else "下一题") }
                }
            }
        }

        if (finished) {
            SectionCard(title = "本次成绩") {
                Text("$score / ${items.size}", style = MaterialTheme.typography.headlineSmall, color = Ink)
                Text(
                    when {
                        score == items.size -> "全部答对，非常稳。"
                        score * 2 >= items.size -> "正确率过半，把错题复习一遍再挑战。"
                        else -> "先回到字母与词汇基础，再闯一次。"
                    },
                    color = Ink.copy(alpha = 0.75f)
                )
                Button(onClick = { restart(level) }) { Text("重新挑战") }
            }
        }
    }
}

private fun buildQuiz(level: String): List<QuizItem> {
    val rnd = Random(System.currentTimeMillis())
    return when (level) {
        "进阶" -> {
            val vocab = CourseData.vocab.shuffled(rnd).take(5).map { v ->
                val pool = CourseData.vocab.filter { it.thai != v.thai }.shuffled(rnd).take(3).map { it.thai }
                val options = (listOf(v.thai) + pool).shuffled(rnd)
                QuizItem(
                    kind = "vocab_th",
                    prompt = v.zh,
                    sub = "中文对应哪个泰语词？",
                    options = options,
                    answer = options.indexOf(v.thai),
                    refKey = SrsEngine.vocabKey(v.thai)
                )
            }
            val letters = CourseData.consonants.shuffled(rnd).take(5).map { l ->
                val opts = listOf("中辅音", "高辅音", "低辅音")
                QuizItem(
                    kind = "letter_class",
                    prompt = "「${l.char}」是哪一类辅音？",
                    sub = l.name,
                    options = opts,
                    answer = opts.indexOf(l.cls).coerceAtLeast(0),
                    refKey = SrsEngine.letterKey(l.char),
                    spokenThai = l.char
                )
            }
            (vocab + letters).shuffled(rnd)
        }
        "听力" -> (1..8).map {
            val tone = CourseData.fiveTones.random(rnd)
            QuizItem(
                kind = "tone_name",
                prompt = "听音辨调",
                sub = "点击播放，判断这个音节的声调。",
                options = CourseData.fiveTones.map { t -> t.zhName },
                answer = CourseData.fiveTones.indexOfFirst { t -> t.key == tone.key },
                refKey = SrsEngine.toneKey(tone.key),
                toneKey = tone.key
            )
        }
        else -> CourseData.vocab.shuffled(rnd).take(8).map { v ->
            val pool = CourseData.vocab.filter { it.thai != v.thai }.shuffled(rnd).take(3).map { it.zh }
            val options = (listOf(v.zh) + pool).shuffled(rnd)
            QuizItem(
                kind = "vocab_zh",
                prompt = v.thai,
                sub = "这个泰语词是什么意思？",
                options = options,
                answer = options.indexOf(v.zh),
                refKey = SrsEngine.vocabKey(v.thai),
                spokenThai = v.thai
            )
        }
    }
}
