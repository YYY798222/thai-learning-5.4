package com.example.thailearning.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.thailearning.data.CourseData
import com.example.thailearning.data.Progress
import com.example.thailearning.engine.PlanEngine

@Composable
fun PlanScreen(
    progress: Progress,
    onToggleTask: (Int, Int) -> Unit,
    onCompleteDay: (Int) -> Unit,
    onRestart: () -> Unit
) {
    val currentDay = PlanEngine.currentDay(progress)
    var selectedDay by remember { mutableIntStateOf(currentDay) }
    val plan = CourseData.plan.getOrNull(selectedDay - 1) ?: CourseData.plan.first()
    val unlocked = PlanEngine.isUnlocked(progress, selectedDay)
    val completed = PlanEngine.isCompleted(progress, selectedDay)
    val checks = PlanEngine.checks(progress, selectedDay)
    val percent = PlanEngine.progressPercent(progress)

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionCard(title = "30 天零基础学习计划") {
            Text("今天是第 $currentDay 天 · 连续学习 ${progress.streak} 天", color = Ink, fontWeight = FontWeight.Medium)
            LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth())
            Text("已完成 ${progress.completedDays.size} / 30 天（$percent%）", style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = 0.65f))
            Text(
                "每天 15-30 分钟：看笔顺 → 听发音 → 做练习。完成当天 3 项任务后打勾结业，第二天自动解锁。",
                style = MaterialTheme.typography.bodySmall,
                color = Ink.copy(alpha = 0.65f)
            )
            if (progress.completedDays.isNotEmpty()) {
                TextButton(onClick = onRestart) { Text("重置 30 天进度（不会删除错题）") }
            }
        }

        SectionCard(title = "第 ${plan.day} 天 · ${plan.title}") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("建议 ${plan.minutes} 分钟", color = Ink.copy(alpha = 0.7f))
                Text(
                    when {
                        completed -> "已完成 ✓"
                        !unlocked -> "未解锁"
                        else -> "进行中"
                    },
                    color = if (completed) Jade else if (!unlocked) Ink.copy(alpha = 0.5f) else Gold,
                    fontWeight = FontWeight.Medium
                )
            }
            if (!unlocked) {
                Text("按顺序完成前一天后自动解锁；也可以先看内容，但打卡从第 1 天开始。", style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = 0.6f))
            }
            if (plan.letters.isNotEmpty()) {
                Text("今日字形", style = MaterialTheme.typography.labelLarge, color = Ink)
                Text(plan.letters.joinToString("  "), style = MaterialTheme.typography.titleLarge, color = Jade)
            }
            if (plan.words.isNotEmpty()) {
                Text("今日词汇", style = MaterialTheme.typography.labelLarge, color = Ink)
                Text(plan.words.joinToString(" · "), color = Ink)
            }
            Text("任务", style = MaterialTheme.typography.labelLarge, color = Ink)
            plan.tasks.forEachIndexed { idx, task ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(Modifier.weight(1f)) {
                        Checkbox(
                            checked = idx in checks,
                            onCheckedChange = { if (unlocked && !completed) onToggleTask(plan.day, idx) }
                        )
                        Text(task, Modifier.padding(top = 12.dp), color = Ink)
                    }
                }
            }
            Text("提示：${plan.tip}", style = MaterialTheme.typography.bodySmall, color = Ink.copy(alpha = 0.7f))
            if (completed) {
                Text("这一天的任务已全部完成，继续保持。", color = Jade)
            } else {
                Button(
                    enabled = unlocked && PlanEngine.allTasksDone(progress, plan.day),
                    onClick = { onCompleteDay(plan.day) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        if (PlanEngine.allTasksDone(progress, plan.day)) "完成第 ${plan.day} 天（+25 XP）" else "先勾选全部任务"
                    )
                }
            }
        }

        SectionCard(title = "30 天进度表") {
            (1..30).chunked(6).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    row.forEach { day ->
                        val isDone = PlanEngine.isCompleted(progress, day)
                        val isToday = day == currentDay
                        val isUnlocked = PlanEngine.isUnlocked(progress, day)
                        TextButton(
                            onClick = { selectedDay = day },
                            modifier = Modifier.weight(1f),
                            enabled = isUnlocked || isDone
                        ) {
                            Column {
                                Text(
                                    "$day",
                                    color = when {
                                        isDone -> Jade
                                        isToday -> Gold
                                        isUnlocked -> Ink
                                        else -> Ink.copy(alpha = 0.35f)
                                    },
                                    fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal
                                )
                                Text(
                                    if (isDone) "✓" else if (isUnlocked) "·" else "锁",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Ink.copy(alpha = 0.45f)
                                )
                            }
                        }
                    }
                    repeat(6 - row.size) { Column(Modifier.weight(1f)) {} }
                }
            }
        }
    }
}
