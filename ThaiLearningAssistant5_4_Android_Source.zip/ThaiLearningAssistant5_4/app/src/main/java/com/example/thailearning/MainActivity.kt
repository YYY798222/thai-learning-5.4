package com.example.thailearning

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.example.thailearning.audio.ToneSynth
import com.example.thailearning.ui.ThaiApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speech: SpeechRecognizer? = null
    private var speechCallback: ((String) -> Unit)? = null

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) speechCallback?.invoke("未获得麦克风权限，请在系统设置中允许录音。")
        else startSpeechInternal()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            ThaiApp(
                speak = { speakThai(it) },
                playContour = { contour -> ToneSynth.playOne(contour) },
                playPair = { a, b -> ToneSynth.playPair(a, b) },
                askAI = { endpoint, key, question -> callDeepSeek(endpoint, key, question) },
                startSpeech = { callback -> speechCallback = callback; requestSpeech() },
                loadConfig = { loadConfig() },
                saveConfig = { endpoint, key -> saveConfig(endpoint, key) }
            )
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("th", "TH"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            if (!ttsReady) {
                // 退而求其次：仍尝试默认语音，界面上的声调训练不依赖 TTS
                tts?.setLanguage(Locale.getDefault())
            }
        }
    }

    private fun speakThai(text: String) {
        if (text.isBlank()) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "thai-tts")
    }

    private fun requestSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speechCallback?.invoke("此设备没有可用的语音识别服务。")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startSpeechInternal()
        } else {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startSpeechInternal() {
        try {
            speech?.destroy()
            speech = SpeechRecognizer.createSpeechRecognizer(this)
            speech?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    speechCallback?.invoke("识别未成功（代码 $error）。请检查网络、麦克风和设备语音识别服务。")
                }
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    speechCallback?.invoke(if (text.isBlank()) "没有识别到语音，请再试一次。" else text)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "th-TH")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            speech?.startListening(intent)
        } catch (e: Exception) {
            speechCallback?.invoke("启动语音识别失败：${e.message}")
        }
    }

    private fun securePrefs() = EncryptedSharedPreferences.create(
        this,
        "thai_secure",
        MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private fun loadConfig(): Pair<String, String> = try {
        val p = securePrefs()
        (p.getString("endpoint", "https://api.deepseek.com/chat/completions") ?: "") to (p.getString("api_key", "") ?: "")
    } catch (_: Exception) {
        "https://api.deepseek.com/chat/completions" to ""
    }

    private fun saveConfig(endpoint: String, key: String) {
        securePrefs().edit().putString("endpoint", endpoint).putString("api_key", key).apply()
    }

    private suspend fun callDeepSeek(endpoint: String, key: String, question: String): String = withContext(Dispatchers.IO) {
        if (key.isBlank()) return@withContext "请先在「AI」页填写 DeepSeek API Key。"
        var conn: HttpURLConnection? = null
        try {
            conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20000
                readTimeout = 60000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Authorization", "Bearer $key")
            }
            val payload = JSONObject().apply {
                put("model", "deepseek-chat")
                put(
                    "messages",
                    JSONArray()
                        .put(JSONObject().put("role", "system").put("content", SYSTEM_PROMPT))
                        .put(JSONObject().put("role", "user").put("content", question))
                )
                put("temperature", 0.6)
            }
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                "AI 请求失败（HTTP $code）：${runCatching { JSONObject(body).optString("error", body) }.getOrDefault(body)}"
            } else {
                JSONObject(body).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                    ?: "AI 返回内容为空。"
            }
        } catch (e: Exception) {
            "连接失败：${e.localizedMessage ?: e.javaClass.simpleName}"
        } finally {
            conn?.disconnect()
        }
    }

    override fun onDestroy() {
        speech?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val SYSTEM_PROMPT =
            "你是一位耐心的泰语老师，学生是中文母语的零基础学习者。请用中文解释，" +
                "每次回答都给出：泰语原文、罗马音、中文意思、声调分析（辅音类别+元音长短+韵尾+符号）、" +
                "使用场景与 1-2 个例句；如涉及书写，请说明笔顺结构（头圈/主体/收尾），不要编造不确定的语法规则。"
    }
}
